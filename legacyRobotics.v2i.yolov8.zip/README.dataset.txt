# legacyRobotics > 2024-01-24 4:37pm
https://universe.roboflow.com/legacy-kqgrw/legacyrobotics

Provided by a Roboflow user
License: CC BY 4.0

